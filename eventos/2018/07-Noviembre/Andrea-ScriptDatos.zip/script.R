
library(readr)
datos <- read_csv("C:/fatales.csv")
attach(datos)
names(datos)
library(mosaic)
favstats(edad~genero)
boxplot(edad~genero)
mean(edad)
sd(edad)

n=20
N=1000
meanN=numeric(N)
for (i in 1:N)
  meanN[i]=mean(sample(edad,n,replace=F))
hist(meanN,freq=F)
sd(meanN)

set.seed(15)
muestra=sample(edad,n,replace=F)

B=1000
meanB=numeric(B)
for (i in 1:B)
  meanB[i]=mean(sample(muestra,n,replace=T))
hist(meanB,freq=F)

par(mfrow =c(1,2))
hist(meanN,freq=F)
hist(meanB,freq=F)


c(mean(muestra)-2*sd(meanB),mean(muestra)+2*sd(meanB))

######################################################
library(bootstrap)
media=function(x){mean(x)}

mediasB=bootstrap(muestra,B,media)$thetastar
hist(meanB,freq=F)


quant25=function(x){quantile(x,.25)}
quant25B=bootstrap(muestra,B,quant25)$thetastar
hist(quant25B,freq=F)
alfa=.05
quantile(quant25B,c(alfa/2,1-alfa/2))
         
###############################################
## Efrom & Tibshirani (1993) Introduction to the Bootstrap
str(law)

str(law82)
plot(law)


theta <- function(ind) cor(law[ind,1], law[ind,2])
theta(1:15) # sample estimate

law.boot <- bootstrap(1:15, 2000, theta)
sd(law.boot$thetastar) # bootstrap standard error
hist(law.boot$thetastar)
# bootstrap t confidence limits for the correlation coefficient:

alfa=.05
quantile(law.boot$thetastar,c(alfa/2,1-alfa/2))
